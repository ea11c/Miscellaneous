Description:

The threadpool is created by making an array of threads, a pointer to a 
_queue for the task_queue, a mutex for locking, a conditional variable for signaling 
threads, and 2 ints used as flags for shutting down and when to accept more tasks.

The _queue struct is implemented like a linked list and contains a head and tail 
pointer for _nodes.

The _node struct contains the function the task is supposed to execute, it's 
arguments, and a pointer to the next node.

Critical Sections:

thread_main contains a critical section while it is looping.  This is a critical 
section beccause it potentially edits information in the main thread by calling 
dequeue.

dispatch contains a critical section when it attempts to enqueue a task, because this 
involves editing information in the main thread.

destroy_threadpool contains a critical section because it must wait for every thread 
to return before it can delete them.
	
Synchronization & Condition Variables:

1 pthread_cond_t was used in the following places:

	thread_main to wait for the queue to not be empty, and to signal if it 
	becomes empty after dequeue.

	dispatch to signal that the queue is not empty anymore.

	destroy_threadpool to signal that the queue is empty, the shutdown process 
	has started, and that each thread can join back to the main thread.

The main thread is responsible for waking up a blocked thread, which can occur when 
the task_queue is empty and not in shutdown.
