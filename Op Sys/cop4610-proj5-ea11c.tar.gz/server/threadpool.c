/**
 * threadpool.c
 *
 * This file will contain your implementation of a threadpool.
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>

#include "threadpool.h"

// _threadpool is the internal threadpool structure that is
// cast to type "threadpool" before it given out to callers

typedef struct _node{
	void (*routine) (void*);
	void * arg;
	struct _node* next;
} _node;

typedef struct _queue{
	_node* qhead;
	_node* qtail;
	int qsize;
} _queue;

typedef struct _threadpool_st {
   // you should fill in this structure with whatever you need
	int num_threads;	//number of active threads
	pthread_t *threads;	//pointer to threads
	_queue* tq;		//pointer to tassk queue
	pthread_mutex_t qlock;		//lock on the queue list
	pthread_cond_t condvar;
	int shutdown;
	int dont_accept;
} _threadpool;

void init_queue(_queue *q){
	q->qhead = NULL;
	q->qtail = NULL;
	q->qsize = 0;
}

int queue_empty(_queue *q){
	if(q->qsize == 0)
		return 0;
	else
		return q->qsize;
}

void enqueue(_queue *q, _node *n){
	if(queue_empty(q) == 0) {
                q->qhead = n;  //set to only one
                q->qtail = n;
        } else {
                q->qtail->next = n;    //add to end;
                q->qtail = n;                  
        }
        q->qsize++;
}

_node* dequeue(_queue *q){
	_node *n = q->qhead;
        q->qsize--;

        if(queue_empty(q) == 0) {
                q->qhead = NULL;
        	q->qtail = NULL;
        }
        else {
        	q->qhead = n->next;
        }
	return n;
}

/* This function is the work function of the thread */
void* thread_main(threadpool p) {
	_threadpool * pool = (_threadpool *) p;
	_node* cur;	//The q element
	int k;

	while(1) {
		pthread_mutex_lock(&(pool->qlock));  //get the q lock.

		while( pool->tq->qsize == 0) {	//if the size is 0 then wait.  
			if(pool->shutdown) {
				pthread_mutex_unlock(&(pool->qlock));
				pthread_exit(NULL);
			}
			//wait until the condition says its no emtpy and give up the lock. 
			pthread_mutex_unlock(&(pool->qlock));  //get the qlock.
			pthread_cond_wait(&(pool->condvar),&(pool->qlock));
			//check to see if in shutdown mode.
			if(pool->shutdown) {
				pthread_mutex_unlock(&(pool->qlock));
				pthread_exit(NULL);
			}
		}

		cur = dequeue(pool->tq); 
		
		if(queue_empty(pool->tq) == 0 && ! pool->shutdown) {
			//the q is empty again, now signal that its empty.
			pthread_cond_signal(&(pool->condvar));
		}
		pthread_mutex_unlock(&(pool->qlock));
		(cur->routine) (cur->arg);   //actually do work.
		free(cur);		//free the work storage.  	
	}
}

threadpool create_threadpool(int num_threads_in_pool) {
  _threadpool *pool;
	int i;

  // sanity check the argument
  if ((num_threads_in_pool <= 0) || (num_threads_in_pool > MAXT_IN_POOL))
    return NULL;

  pool = (_threadpool *) malloc(sizeof(_threadpool));
  if (pool == NULL) {
    fprintf(stderr, "Out of memory creating a new threadpool!\n");
    return NULL;
  }
  pool->tq = (_queue*) malloc(sizeof(_queue) * num_threads_in_pool);
  pool->threads = (pthread_t*) malloc (sizeof(pthread_t) * num_threads_in_pool);

  if(!pool->threads) {
    fprintf(stderr, "Out of memory creating a new threadpool!\n");
    return NULL;	
  }

  pool->num_threads = num_threads_in_pool; //set up structure members
  pool->shutdown = 0;
  pool->dont_accept = 0;

  //initialize mutex and condition variables.  
  if(pthread_mutex_init(&pool->qlock,NULL)) {
    fprintf(stderr, "Mutex initiation error!\n");
	return NULL;
  }
  if(pthread_cond_init(&(pool->condvar),NULL)) {
    fprintf(stderr, "CV initiation error!\n");	
	return NULL;
  }
  //make threads

  for (i = 0;i < num_threads_in_pool;i++) {
	  if(pthread_create(&(pool->threads[i]),NULL,thread_main,pool)) {
	    fprintf(stderr, "Thread initiation error!\n");	
		return NULL;		
	  }
  }
  return (threadpool) pool;
}


void dispatch(threadpool from_me, dispatch_fn dispatch_to_here,
	      void *arg) {
  _threadpool *pool = (_threadpool *) from_me;
	_node * cur;
	int k;

	//make a work queue element.  
	cur = (_node*) malloc(sizeof(_node));
	if(cur == NULL) {
		fprintf(stderr, "Out of memory creating a work struct!\n");
		return;	
	}

	cur->routine = dispatch_to_here;
	cur->arg = arg;
	cur->next = NULL;

	pthread_mutex_lock(&(pool->qlock));

	if(pool->dont_accept) { //Just incase someone is trying to queue more
		free(cur); //work structs.  
		return;
	}
	enqueue(pool->tq, cur);
	if(queue_empty(pool->tq) == 1){
		pthread_cond_signal(&(pool->condvar));
	}
	pthread_mutex_unlock(&(pool->qlock));  //unlock the queue.
}

void destroy_threadpool(threadpool destroyme) {
	_threadpool *pool = (_threadpool *) destroyme;
	void* nothing;
	int i = 0;

	pthread_mutex_lock(&(pool->qlock));
	pool->dont_accept = 1;
	while(queue_empty(pool->tq) != 0) {
		pthread_cond_wait(&(pool->condvar),&(pool->qlock));  
		//wait until the q is empty.
	}
	pool->shutdown = 1;  //allow shutdown
	pthread_cond_broadcast(&(pool->condvar));
	pthread_mutex_unlock(&(pool->qlock));

	//kill everything.  
	for(;i < pool->num_threads;i++) {
		pthread_cond_broadcast(&(pool->condvar));
		//allowcode to return NULL;/
		pthread_join(pool->threads[i],&nothing);
	}

	free(pool->threads);

	pthread_mutex_destroy(&(pool->qlock));
	pthread_cond_destroy(&(pool->condvar));
	return;
}

