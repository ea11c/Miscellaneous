#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <string.h>

struct cmd {
	char* name;
	char* args[200];
};

int main( int argc, char *argv[] ) {

struct cmd commands[512];
int mode = 0;
char str[1024];
FILE *batch;
char* token;
char* delim = ";";
int num_procs = 0; //used to track how many processes are running
char* prompt = "prompt> ";
int i = 0;
int j = 0;
pid_t pid;
int status;
int quit_flag = 0;

//error check number of command line args
if (argc >= 3) {
	perror("Too many command line arguments given, exiting shell now.");
	exit(0);
}
//running in batch mode
else if (argc == 2) {
	mode = 1;
	batch = fopen(argv[1] , "r");
	if (batch == NULL) {
		perror("Could not open batch file, exiting shell.");
		exit(0);
	}
}
//running in interactive mode
else {
	batch = stdin;
}

//loop to get instructions
printf("%s", prompt);
while (fgets(str, 1024, batch) != NULL) {
	delim = ";";
	num_procs = 0;
	token = strtok(str, delim);
	i = 0;
	//parse instructions to get individual commands
	while (token != NULL) {
		commands[num_procs].name = token;
		num_procs += 1;
		if (mode == 1) {
			printf("Executing command: %s \n", token);
		}
		token = strtok(NULL, delim);
	}
	//parse individual commands to get arguments
	while (i <= num_procs) {
		delim = " \t\r\n\v\f ";  //all whitespace
		j = 0;
		token = strtok(commands[i].name, delim);
		while (token != NULL) {
			commands[i].args[j] = token;
			if (strcmp(token, "quit") == 0) {
				quit_flag = 1;
			}
			j += 1;
			token = strtok(NULL, delim);
		}
		pid = fork();
		if(pid < 0) {
			perror("Unable to fork command.");
		}
		else if (pid == 0) {//in child, exec command
			if (strcmp(commands[i].args[0], "quit") == 0) {
				break;
			}
			execvp(commands[i].args[0], commands[i].args);
			printf("Can't execute command: %s \n", commands[i].args[0]);
			
		}
		i += 1;
	}
	i = 0;
	while (i <= num_procs) {
		pid = wait(&status);
		j = 0;
		while(commands[i].args[j] != NULL) {
			commands[i].args[j] = NULL;
			j += 1;
		}
		commands[i].name = NULL;
		i += 1;
	}
	if (quit_flag == 1) {
		exit(0);
	}
	if (mode ==0) {
		printf("%s", prompt);	
	}
}
if (mode == 1) {
	fclose(batch);
}
return 0;
}
