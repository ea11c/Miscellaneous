#include "types.h"
#include "stat.h"
#include "user.h"
#include "uproc.h"

int main() {
  const int MAX = 64;
  struct uproc *p = malloc(MAX * sizeof(struct uproc));
  int i = getprocs(MAX, p);
  int j;
  char spaces[] = "   ";
  for(j = 0; j < i; j++)
  {
    if(j == 0)
      printf(1, "%s[%d]\n", p[j].name, p[j].pid);
    else
    {
      if(p[j].ppid == p[j-1].pid)
        printf(1, "%s%s[%d]\n%s", spaces, p[j].name, p[j].pid, spaces);
      else
	printf(1, "%s%s[%d]\n", spaces, p[j].name, p[j].pid);
    }
  }

  exit();
}
