#include "types.h"
#include "x86.h"
#include "defs.h"
#include "date.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"
#include "uproc.h"
#include "spinlock.h"

int
sys_fork(void)
{
  return fork();
}

int
sys_exit(void)
{
  exit();
  return 0;  // not reached
}

int
sys_wait(void)
{
  return wait();
}

int
sys_kill(void)
{
  int pid;

  if(argint(0, &pid) < 0)
    return -1;
  return kill(pid);
}

int
sys_getpid(void)
{
  return proc->pid;
}

int
sys_sbrk(void)
{
  int addr;
  int n;

  if(argint(0, &n) < 0)
    return -1;
  addr = proc->sz;
  if(growproc(n) < 0)
    return -1;
  return addr;
}

int
sys_sleep(void)
{
  int n;
  uint ticks0;

  if(argint(0, &n) < 0)
    return -1;
  acquire(&tickslock);
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    if(proc->killed){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);
  return 0;
}

// return how many clock tick interrupts have occurred
// since start.
int
sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}

extern struct {
  struct spinlock lock;
  struct proc proc[NPROC];
} ptable;

int
sys_getprocs(void)
{
  struct uproc *p;
  int items = 0;
  int max, j;
  struct proc *i;  

  if(argint(0, &max) < 0)
    return -2;
  if(argptr(1, (char**)&p, max * sizeof(struct uproc)) < 0)
    return -1;
  acquire(&ptable.lock);
//for loop to copy data from p to struct uproc if valid
  for(i = ptable.proc; i < &ptable.proc[NPROC]; i++)
  {
    if(i->state == UNUSED)
      continue;
    else
    {

      p[items].pid = i->pid;
      p[items].ppid = i->parent->pid;
      for(j = 0; j < 16; j++)
        p[items].name[j] = i->name[j];
    
      items++;
    }
  }
  release(&ptable.lock);
  return items;
}

